
public class Pedido {
	//propiedades
	private int numeroDeSerie;
	private String fecha;
	private Cliente cliente;
	private float cuantiaTotal;
	
	//Setters and Getters

	//metodos
	
}
