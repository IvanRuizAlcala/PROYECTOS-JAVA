public class PedidoComercial extends Pedido {
	// propiedades
	private Vendedor vendedor;
	private int matricula;

	
}
