
public class Vendedor {

}
