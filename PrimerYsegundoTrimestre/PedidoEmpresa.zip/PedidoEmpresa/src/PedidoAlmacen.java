
public class PedidoAlmacen extends Pedido{
	//propiedades
	private Dependiente dependiente;
	private int numeroMostrador;

	//Getters and Setters
	
}
