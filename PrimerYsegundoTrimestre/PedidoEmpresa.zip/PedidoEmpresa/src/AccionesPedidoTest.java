import static org.junit.Assert.*;

import java.util.Vector;

import org.junit.Test;


public class AccionesPedidoTest {
	Vector<PedidoComercial> listaPedido=new Vector<>();
	@Test
	public void test() {
	

	}

}
