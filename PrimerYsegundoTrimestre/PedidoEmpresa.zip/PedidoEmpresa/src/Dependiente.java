
public class Dependiente {

}
